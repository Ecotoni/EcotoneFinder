## ---- include = FALSE, echo = FALSE-------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = NA,
  #tidy.opts=list(width.cutoff=60), 
  results = 'markup',
  #tidy='styler', ## if pdf
  #tidy=TRUE,
  global.par = TRUE#,
  #eval = TRUE
)

## ----Fig1, echo=FALSE, fig.align="center", fig.cap="General organisation chart of the R-package, from raw data to typical outputs. It may be subdivided in several main sections: (i) functions to explore the internal structure of the raw data, (ii) main data analyses for ecotones and communities characterisation, (iii) plotting functions, (iv) functions to extract ecotone parameters, (v) functions to access community compositions and (vi) extensions of these functions for data series.", out.width = '80%'----
knitr::include_graphics("AnalysesDiagram.pdf")

## ----setup--------------------------------------------------------------------
library(EcotoneFinder)

## ----Fig2, warning=FALSE, message=FALSE, fig.show="hold", out.width='50%', fig.cap="Examples of artificial data with 2 and 3 communities"----
# 2 Communities - 26 species:
Community2 <- SyntheticData(SpeciesNum=26, CommunityNum=2, SpCo=NULL, Length = 500,
                            Parameters=list(a=c(60, 60), b=c(0, 500), c=c(0.009, 0.009)),
                            dev.c = .0024, dev.a = 25, dev.b = 30, 
                            pal=c("#008585", "#C7522B"),
                            title = "2 communities")

# 3 Communities - 39 species:
Community3 <- SyntheticData(SpeciesNum=39, CommunityNum=3, SpCo=NULL, Length = 500,
                            Parameters=list(a=c(60, 60, 60), b=c(0, 250, 500), 
                                            c=c(0.015, 0.015, 0.015)),
                            dev.c = .0024, dev.a = 35, dev.b = 25, 
                            pal=c("#008585", "#B8CDAE", "#C7522B"),
                            title = "3 communities")

## ----Fig3, warning=FALSE, message=FALSE, fig.show="hold", out.width='33%', fig.cap="Examples of artificial data with different gaussian parameters"----
# 2 Communities - a = 80 and a = 40:
Community2 <- SyntheticData(SpeciesNum=26, CommunityNum=2, SpCo=NULL, Length = 500,
                            Parameters=list(a=c(80, 40), b=c(0, 500), c=c(0.009, 0.009)),
                            dev.c=.0024, dev.a = 25, dev.b = 30, 
                            pal=c("#008585", "#C7522B"),
                            title = "a = 80 and a = 40")

# 2 Communities - b = 150 and b = 350:
Community2 <- SyntheticData(SpeciesNum=26, CommunityNum=2, SpCo=NULL, Length = 500,
                            Parameters=list(a=c(60, 60), b=c(100, 400), 
                                            c=c(0.009, 0.009)),
                            dev.c=.0024, dev.a = 25, dev.b = 30, 
                            pal=c("#008585", "#C7522B"),
                            title = "b = 150 and b = 350")

# 2 Communities - c = 0.005 and c = 0.012:
Community2 <- SyntheticData(SpeciesNum=26, CommunityNum=2, SpCo=NULL, Length = 500,
                            Parameters=list(a=c(60, 60), b=c(0, 500), c=c(0.005, 0.012)),
                            dev.c=.0024, dev.a = 25, dev.b = 30, 
                            pal=c("#008585", "#C7522B"),
                            title = "c = 0.005 and c = 0.012")


## ----Fig4, warning=FALSE, message=FALSE, fig.show="hold", out.width='33%', fig.cap="Control of the number of species per communities, of the gaussian parameter deviations and of particular groups of species in community types."----
# 2 Communities with unequal species numbers:
Community2 <- SyntheticData(SpeciesNum=30, CommunityNum=2, SpCo=c(10,20), Length = 500,
                            Parameters=list(a=c(60, 60), b=c(0, 500), c=c(0.009, 0.009)),
                            dev.c=.0024, dev.a = 25, dev.b = 30, 
                            pal=c("#008585", "#C7522B"),
                            title = "Unequal species numbers")

# Adding parameter deviations:
Community2 <- SyntheticData(SpeciesNum=30, CommunityNum=2, SpCo=NULL, Length = 500,
                            Parameters=list(a=c(60, 60), b=c(0, 500), c=c(0.009, 0.009)),
                            dev.c=.005, dev.a = 50, dev.b = 60, 
                            pal=c("#008585", "#C7522B"),
                            title = "Parameter deviation")

# Adding complexity:
Community2 <- SyntheticData(SpeciesNum=60, CommunityNum=4, SpCo=c(20,10,10,20), 
                            Length = 500,
                            Parameters=list(a=c(60, 30, 40, 70), b=c(0,0,500,500), 
                                            c=c(0.015, 0.008, 0.007, 0.01)),
                            dev.c=.0024, dev.a = 25, dev.b = 30, 
                            pal=c("#008585", "#AAC1A8", "#D58545", "#C7522B"),
                            title = "Pools of species inside community types")


## ----Fig5, warning=FALSE, message=FALSE, fig.show="hold", out.width='33%', fig.cap="Time series with varying number of species par community types and per series."----

### Series:
Series <- SyntheticDataSeries(CommunityPool = 30, CommunityNum = 3, Length = 500,
                              SeriesNum = 6, replacement = TRUE, range.repl = 20,
                              #SpCo = c(30,30,30),
                              Parameters = list(a = c(60,60,60),
                                                b = c(100,250,400),
                                                c = c(0.015, 0.02, 0.02)),
                              dev.a=30, dev.b=40, dev.c=0.005,
                              pal = c("#008585", "#E6C186", "#C7522B"))
 

## ----Fig6, warning=FALSE, message=FALSE, fig.show="hold", out.width='33%', fig.cap="Time series with displacement: part of the first community (left) advances toward the right-end of the gradient by 35 gradient units per series, as if reacting to a moving environmental variable. The last community also withdraw even further to the right, but slower (10 gradient units per series)."----
## Displacement matrix:
disp <- matrix(data=c(0,0,0,
                      0,35,-0.0007,
                      0,10,0), nrow = 3, ncol = 3)

### Series:
Series <- SyntheticDataSeries(CommunityPool = 60, CommunityNum = 3, Length = 500,
                              SeriesNum = 6, replacement = FALSE, SpCo = c(15,15,30),
                              Parameters = list(a = c(60,60,60),
                                                b = c(-50,-50,400),
                                                c = c(0.01, 0.01, 0.01)),
                              dev.a=30, dev.b=40, dev.c=0,
                              displacement = disp,
                              pal = c(rep("#008585",15), rep("#E6C186",15),
                                      rep("#C7522B",30)))
 

## ----Fig7, warning=FALSE, message=FALSE, fig.show="hold", out.width='40%', fig.align="center", fig.cap="Heatmaps and Networks, based on the example artificial communities presented above in Fig. 2"----
# 2 Communities - 26 species:
Community2 <- SyntheticData(SpeciesNum=26, CommunityNum=2, SpCo=NULL, Length = 500,
                            Parameters=list(a=c(60, 60), b=c(0, 500), c=c(0.009, 0.009)),
                            dev.c=.0024, dev.a = 25, dev.b = 30, 
                            pal=c("#008585", "#C7522B"),
                            title = "2 communities")

# 3 Communities - 39 species:
Community3 <- SyntheticData(SpeciesNum=39, CommunityNum=3, SpCo=NULL, Length = 500,
                            Parameters=list(a=c(60, 60, 60), b=c(0, 250, 500), 
                                            c=c(0.015, 0.015, 0.015)),
                            dev.c=.0024, dev.a = 35, dev.b = 25, 
                            pal=c("#008585", "#B8CDAE", "#C7522B"),
                            title = "3 communities")

# Heat maps:
HeatMap2 <- DistEco(Community2[,2:ncol(Community2)], transpose = T, symm = F, 
                    plot = c("heatmap"))
HeatMap3 <- DistEco(Community3[,2:ncol(Community3)], transpose = T, symm = F, 
                    plot = c("heatmap"))

# Networks (with spinglass algorithm for statistical communities):
Network2 <- DistEco(Community2[,2:ncol(Community2)], transpose = T, symm = F,
                    plot = c("network"), spinglass = T, run = 5, 
                    spinglass.groups = c("rounded"))
Network3 <- DistEco(Community3[,2:ncol(Community3)], transpose = T, symm = F,
                    plot = c("network"), spinglass = T, run = 5, 
                    spinglass.groups = c("rounded"))

## ----Fig8, warning=FALSE, message=FALSE, fig.show="hold", out.width='40%', fig.align="center", fig.cap="Clustergram plots on fuzzy c-means algorithms, with associated fuzzy partition indices, for 3 and 6 artificial communities. The normalised partition coefficient (red) should be maximized, whereas the normalised partition entropy (blue) should be minimized."----
######## clustergram plots (on fuzzy c-means algorithm):
## with the previous '3 communities' example:
clustergramInd(as.matrix(Community3[,2:ncol(Community3)]),
                         clustering.function = clustergram.vegclust.Ind,
                         clustergram.plot = clustergram.plot.matlines,
                         FuzzyIndice.plot = FuzzyIndice.plot.matlines,
                         k.range = 2:10, line.width = .2)

######## clustergram plots (on fuzzy c-means algorithm):
## with 6 artificial communities:
Community6 <- SyntheticData(SpeciesNum=60, CommunityNum=6, SpCo=NULL, Length = 500,
                            Parameters=list(a=rep(60, times = 6), b=seq(0,500, by = 100), 
                                            c=rep(0.03, times = 6)),
                            dev.c=.0024, dev.a = 35, dev.b = 25, 
                            pal=rep(c("#008585", "#B8CDAE", "#C7522B"), times =2),
                            title = "6 communities",
                            plot = FALSE)

clustergramInd(as.matrix(Community6[,2:ncol(Community6)]),
                         clustering.function = clustergram.vegclust.Ind,
                         clustergram.plot = clustergram.plot.matlines,
                         FuzzyIndice.plot = FuzzyIndice.plot.matlines,
                         k.range = 2:10, line.width = .1)


## ----Fig9, warning=FALSE, message=FALSE, fig.show="hold", out.width='50%', fig.cap="Evolution of the first axis of Detrended Correspondance Analyses along the artificial gradient. Plateaux and slopes are indicative of the positions of communities and ecotones, respectively."----
# DCA analyses:
DCA2 <- EcotoneFinder(Community2[,2:ncol(Community2)], dist = Community2$Distance, 
                      method = "dca", standardize = "hellinger")
DCA3 <- EcotoneFinder(Community3[,2:ncol(Community3)], dist = Community3$Distance, 
                      method = "dca", standardize = "hellinger")

# Visualistation:
plotEcotone(data = DCA2, plot.data = FALSE, plot.method = c("dca"), axis.number = 1, 
            col.method = "#26A63A", ylab = "DCA first axis")
plotEcotone(data = DCA3, plot.data = FALSE, plot.method = c("dca"), axis.number = 1, 
            col.method = "#26A63A", ylab = "DCA first axis")


## ----Fig10, warning=FALSE, message=FALSE, fig.show="hold", out.width='50%', fig.cap="Evolution of both the the first and second axis of Detrended Correspondance Analyses along the artificial gradient. The interaction (and particularly intersetion) between the two axis brings some more light on the position of the ecotones and communities."----
plotEcotone(data = DCA2, plot.data = FALSE, plot.method = c("dca"), axis.number = 2, 
            col.method = c("#26A63A", "#FFC183"), ylab = "DCA axis")
plotEcotone(data = DCA3, plot.data = FALSE, plot.method = c("dca"), axis.number = 2, 
            col.method = c("#26A63A", "#FFC183"), ylab = "DCA axis")


## ----Fig11, warning=FALSE, message=FALSE, fig.show="hold", out.width='33%', fig.cap="Evolution of the fuzzy clusters along the gradient, depending on the selected fuzzy algorithm."----
# Fuzzy cluster analyses:
Fuzzy2 <- EcotoneFinder(Community2[,2:ncol(Community2)], dist = Community2$Distance, 
                        method = c("fanny", "vegclust", "cmeans"), groups = 2, m.exp = 2,
                        standardize = "hellinger")
Fuzzy3 <- EcotoneFinder(Community3[,2:ncol(Community3)], dist = Community3$Distance, 
                        method = c("fanny", "vegclust", "cmeans"), groups = 3, m.exp = 2,
                        standardize = "hellinger", seed = 11)

# Visualistation:
plotEcotone(data = Fuzzy2, plot.data = FALSE, plot.method = c("fanny"), 
            col.method = c("#D33F6A", "#E2E6BD"), ylab = "Membership grades",
            title = "Fanny algorithm (2 clusters)")
plotEcotone(data = Fuzzy2, plot.data = FALSE, plot.method = c("vegclust"), 
            col.method = c("#D33F6A", "#E2E6BD"), ylab = "Membership grades",
            title = "Vegclust algorithm (2 clusters)")
plotEcotone(data = Fuzzy2, plot.data = FALSE, plot.method = c("cmeans"), 
            col.method = c("#D33F6A", "#E2E6BD"), ylab = "Membership grades",
            title = "Cmeans algorithm (2 clusters)")
plotEcotone(data = Fuzzy3, plot.data = FALSE, plot.method = c("fanny"), 
            col.method = c("#D33F6A", "#E99A2C", "#E2E6BD"), ylab = "Membership grades",
            title = "Fanny algorithm (3 clusters)")
plotEcotone(data = Fuzzy3, plot.data = FALSE, plot.method = c("vegclust"), 
            col.method = c("#D33F6A", "#E99A2C", "#E2E6BD"), ylab = "Membership grades",
            title = "Vegclust algorithm (3 clusters)")
plotEcotone(data = Fuzzy3, plot.data = FALSE, plot.method = c("cmeans"), 
            col.method = c("#D33F6A", "#E99A2C", "#E2E6BD"), ylab = "Membership grades",
            title = "Cmeans algorithm (3 clusters)")


## ----Fig12, warning=FALSE, message=FALSE, fig.show="hold", out.width='33%', fig.cap="Controling the order of the clusters along the gradient by setting a seed value."----
# Fuzzy cluster analyses:
Fuzzy3 <- EcotoneFinder(Community3[,2:ncol(Community3)], dist = Community3$Distance, 
                        method = c("fanny", "vegclust", "cmeans"), groups = 3, m.exp = 2,
                        standardize = "hellinger", seed = 12)

# Visualistation:
plotEcotone(data = Fuzzy3, plot.data = FALSE, plot.method = c("fanny"), 
            col.method = c("#D33F6A", "#E99A2C", "#E2E6BD"), ylab = "Membership grades",
            title = "Fanny algorithm (3 clusters)")
plotEcotone(data = Fuzzy3, plot.data = FALSE, plot.method = c("vegclust"), 
            col.method = c("#D33F6A", "#E99A2C", "#E2E6BD"), ylab = "Membership grades",
            title = "Vegclust algorithm (3 clusters)")
plotEcotone(data = Fuzzy3, plot.data = FALSE, plot.method = c("cmeans"), 
            col.method = c("#D33F6A", "#E99A2C", "#E2E6BD"), ylab = "Membership grades",
            title = "Cmeans algorithm (3 clusters)")


## ----Fig13, warning=FALSE, message=FALSE, fig.show="hold", out.width='33%', fig.cap="Variations of the species richness, the Shannon-Wiener index, the exponential of the Shannon-Wiener index and the Pielou's eveness along the gradient."----
# Diversity indices:
Diver2 <- EcotoneFinder(Community2[,2:ncol(Community2)], dist = Community2$Distance, 
                        method = c("diversity"), diversity = "all")

# Visualistation:
plotEcotone(data = Diver2, plot.data = FALSE, plot.method = c("diversity"), 
            diversity = c("SpeciesRichness", "ExpShannon"),
            col.method = c("#88C3C8", "#2A5676"), ylab = "Effective number of species",
            title = "Species richness and Exponential of Shannon-Wiener index")
plotEcotone(data = Diver2, plot.data = FALSE, plot.method = c("diversity"), 
            diversity = c("Shannon"),
            col.method = c("#419F44"), ylab = "Index value",
            title = "Shannon-Wiener index")
plotEcotone(data = Diver2, plot.data = FALSE, plot.method = c("diversity"), 
            diversity = c("Pielou"),
            col.method = c("#8346A1"), ylab = "Index value",
            title = "Pielou evenness")


## ---- warning=FALSE, message=FALSE, fig.show="hold", out.width='33%', fig.cap="Controling the order of the clusters along the gradient by setting a seed value."----
# Fuzzy cluster analyses:
EcoFind <- EcotoneFinder(Community3[,2:ncol(Community3)], dist = Community3$Distance, 
                        method = "all", groups = 3, m.exp = 2,
                        diversity = "all",
                        standardize = "hellinger", seed = 12)


## ----Fig14, warning=FALSE, message=FALSE, fig.show="hold", out.width='33%', fig.cap="Basic use of the ggEcotone function for ecotone visualisation."----
# Basic plot:
Plot <- ggEcotone(EcoFind, plot.data = FALSE,
                  method = c("cmeans"),
                  col = c("#D33F6A", "#E99A2C", "#E2E6BD"),
                  title = "fuzzy clusters (cmeans algorithm)",
                  xlab = "Gradient", ylab = "Membership grades")
Plot

# Adding other ggplot layers:
require(ggplot2)
Plot <- Plot + theme_bw() + 
  theme(plot.title = element_text(hjust = 0.5, face="bold"))
Plot

# Add smoothing function:
for (i in 2:ncol(Plot$data)) {
  Plot <- Plot + geom_smooth(data = Plot$data, 
                             aes_string(x = Plot$data[,1], y = Plot$data[,i]), 
                             col = "grey60", lty = 2)
}
Plot

## ----Fig15, warning=FALSE, message=FALSE, fig.show="hold", out.width='50%', fig.cap="Examples of ggEcotone outputs with facets"----
# Comparing the fuzzy algorithms:
Plot <- ggEcotone(EcoFind, plot.data = FALSE,
                  method = c("fanny", "cmeans"),
                  facet = c("fanny", "cmeans"),
                  col = c("#D33F6A", "#E99A2C", "#E2E6BD"),
                  title = "fuzzy clusters",
                  xlab = "Gradient", ylab = "Membership grades") + 
  theme_bw() + 
  theme(plot.title = element_text(hjust = 0.5, face="bold"))
Plot

# This can be used in conjunction with the species response curves:
Plot <- ggEcotone(EcoFind, plot.data = TRUE,
                  method = c("cmeans", "diversity"),
                  col = colorspace::diverging_hcl(39, palette = "Berlin"),
                  diversity = c("SpeciesRichness"),
                  facet = list(c("data"), c("cmeans"), c("diversity")),
                  title = "Species distribution, fuzzy clusters \n and Species richness",
                  xlab = "Gradient", ylab = "Membership grades") + 
  theme_bw() + 
  theme(plot.title = element_text(hjust = 0.5, face="bold"))
Plot

## ----Fig16, warning=FALSE, message=FALSE, fig.show="hold", fig.align="center", out.width='50%', fig.cap="Arranging plots on a grid instead of facetting"----
# Multiplot layout:
Plot1 <- ggEcotone(EcoFind, plot.data = TRUE,
                 method = c("none"), 
                 col = colorspace::diverging_hcl(39, palette = "Berlin"), 
                 facet = NULL,
                 title = "Species distributions", xlab = NULL,
                 ylab = "Abundances") +
  theme_bw() + 
  theme(plot.title = element_text(hjust = 0.5, face="bold"))

Plot2 <- ggEcotone(EcoFind, plot.data = FALSE,
                 method = c("cmeans"), col = c("#023FA5", "#BEC1D4", "#D6BCC0"),
                 facet = NULL, title = "Fuzzy clusters", xlab = NULL,
                 ylab = "Membership grades") +
  theme_bw() + 
  theme(plot.title = element_text(hjust = 0.5, face="bold"))

Plot3 <- ggEcotone(EcoFind, plot.data = FALSE,
                 method = c("diversity"),
                 col = c("#26A63A", "#B4B61A"), facet = NULL,
                 diversity=c("SpeciesRichness", "ExpShannon"),
                 title = "diversity indices", xlab = "Gradient",
                 ylab = "Index scores") +
  theme_bw() + 
  theme(plot.title = element_text(hjust = 0.5, face="bold"))

require(Rmisc)
Rmisc::multiplot(Plot1, Plot2, Plot3)

## ----Fig17, warning=FALSE, message=FALSE, fig.show="hold", out.width='50%', fig.align="center", fig.cap = "Partitioning species into their dominant community type, given fuzzy cluster classification"----
# Colouring function:
ComColour <- CommunityColor(EcoFind, method = "cmeans", palette = "Berlin")

# Species response curve plot:
Plot1 <- ggEcotone(EcoFind, plot.data = TRUE,
                 method = c("none"), col = ComColour, 
                 facet = NULL,
                 title = "Species distributions", xlab = NULL,
                 ylab = "Abundances") +
  theme_bw() + 
  theme(plot.title = element_text(hjust = 0.5, face="bold"))
Plot1


## ----Fig18, warning=FALSE, message=FALSE, fig.show="hold", out.width='33%', fig.align="center", fig.cap = "Barcharts representing the centroid composition of the different fuzzy clusters. Note that normalising centroids per cluster produces equivalent results than the raw values, but it sums up all the values to a hundred for each cluster to facilitate interpretation. When normalised by species, the sum for each species is brought to a hundred. The function may also returns the ggplot object, so that it can be used as a basic ggplot. As the function internally use 'scale\\_fill\\_manual', the 'ggplot2::labs' function should be used with the 'fill' argument."----
# Extracting centroids (raw):
Centroids <- ExtractCentroid(EcoFind, method = "cmeans", normalized = "none", 
                             plot = FALSE, cex.x = 9, col = unique(ComColour))
Centroids$GGplot +
  theme(legend.position = "none")

# Extracting centroids (normalised by species):
Centroids <- ExtractCentroid(EcoFind, method = "cmeans", normalized = "species", 
                             plot = FALSE, cex.x = 9, col = unique(ComColour))
Centroids$GGplot +
  theme(legend.position = "none")

# Extracting centroids (normalised by clusters):
Centroids <- ExtractCentroid(EcoFind, method = "cmeans", normalized = "cluster", 
                             plot = FALSE, cex.x = 9, col = unique(ComColour))
Centroids$GGplot +
  labs(fill = "Clusters")

## ----Fig19, warning=FALSE, message=FALSE, fig.show="hold", out.width='50%', fig.align="center", fig.cap="Artificial data with 2 communities containing overlapping species and non-overlaping species, as well as some species that occur throughout the gradient"----
# Artificial data:
Community <- SyntheticData(SpeciesNum=40, CommunityNum=5, SpCo=c(12,12,5,7,4), 
                           Length = 500,
                           Parameters=list(a=c(60, 60, 20, 15, 60), 
                                           b=c(0, 500, 50, 450, 250), 
                                           c=c(0.01, 0.01, 0.02, 0.02, 0.0001)),
                            dev.c=.0024, dev.a = 20, dev.b = 30, 
                            pal=c("#023FA5", "#8E063B", "#A1A6C8", "#CA9CA4", "grey20"),
                            title = "Communities with localised and ubiquituous species")


## ----Fig20, warning=FALSE, message=FALSE, fig.show="hold", out.width='40%', fig.align="center", fig.cap="Fuzzy centroids"----
## Fuzzy clusters and centroids:
# Fuzzy cluster analyses:
Fuzzy <- EcotoneFinder(Community[,2:ncol(Community)], dist = Community$Distance, 
                        method = c("fanny", "vegclust", "cmeans"), groups = 2, m.exp = 2,
                        standardize = "hellinger", seed = 12)

## Centroids:
# Normalised by clusters:
Centroids <- ExtractCentroid(Fuzzy, method = "cmeans", normalized = "cluster", 
                             plot = FALSE, cex.x = 9, col=c("#A1A6C8", "#CA9CA4"))
Centroids$GGplot +
  theme(legend.position = "none")

# Normalised by species:
Centroids <- ExtractCentroid(Fuzzy, method = "cmeans", normalized = "species", 
                             plot = FALSE, cex.x = 9, col=c("#A1A6C8", "#CA9CA4"))
Centroids$GGplot +
  labs(fill = "Clusters")


## ----Fig21, warning=FALSE, message=FALSE, fig.show="hold", out.width='20%', fig.align="center", fig.cap="Network visualisations of two different relatedness scenarios for three community types (A: Community 1 and 2 are more related, G: Community 2 and 3 are more related). In both cases, the difference in the nerworks is most obvious when selection a threshold for the count of common species (D and J). Networks of species relations within the cluster centroids correctly place the species shared by community types in between the 'defined' community types (after clustering). Actual field data, where species commonly have more complex distribution patterns, are usually more responsive to this type of representations."----
## Artificial communities with different spatial dispositions:
# Communities 1 & 2 closer to each other (by sharing species):
Community12 <- SyntheticData(SpeciesNum=40, CommunityNum=4, SpCo=c(10,10,10,10), 
                             Length = 500,
                             Parameters=list(a=c(60, 60, 60, 60), 
                                             b=c(0, 250, 500, 100), 
                                             c=c(0.012, 0.015, 0.012, 0.009)),
                            dev.c=.0024, dev.a = 20, dev.b = 30, 
                            pal=c("#008585","#B8CDAE","#C7522B", "#72E2AD"),
                            title = "A: Communities 1 & 2 share species")

## Analyses (first case):
Fuzzy12 <- EcotoneFinder(Community12[,2:ncol(Community12)], dist = Community12$Distance, 
                        method = c("cmeans"), groups = 3, m.exp = 2,
                        standardize = "hellinger")
## Networks:
NetworkEco(Fuzzy12, plot.type = "network", method = "cmeans", 
           dist.method = "inner_product", 
           plot = "community", dist = "raw", layout = "spring")
title(main  = "B: Raw distances", adj = 0, cex = .5)
NetworkEco(Fuzzy12, plot.type = "network", method = "cmeans", 
           dist.method = "inner_product", 
           plot = "community", dist = "relative", layout = "spring")
title(main  = "C: Relative distances", adj = 0, cex = .5)
NetworkEco(Fuzzy12, plot.type = "network", method = "cmeans", 
           dist.method = "inner_product", 
           plot = "community", dist = "count", threshold = 0.25, layout = "spring")
title(main  = "D: Number of shared species", adj = 0, cex = .5)

###### Now comparing species with each other:
plot(NULL, xlim=c(0, 1), ylim=c(0, 1), bty ="n",axes=F,
     frame.plot=F, xaxt='n', ann=FALSE, yaxt='n')
NetworkEco(Fuzzy12, plot.type = "network", method = "cmeans", 
           dist.method = "inner_product", 
           plot = "species", dist = "raw", layout = "spring",
           network.group = as.factor(rep(c("C1", "C2", "C3", "Shared C1/C2"), 
                                         each = 10)),
           color = c("#008585","#B8CDAE","#C7522B", "#72E2AD"))
title(main  = "E: Raw distances", adj = 0, cex = .5)
NetworkEco(Fuzzy12, plot.type = "network", method = "cmeans", 
           dist.method = "inner_product", 
           plot = "species", dist = "relative", layout = "spring",
           network.group = as.factor(rep(c("C1", "C2", "C3", "Shared C1/C2"), 
                                         each = 10)),
           color = c("#008585","#B8CDAE","#C7522B", "#72E2AD"))
title(main  = "F: Relative distances", adj = 0, cex = .5)
plot(NULL, xlim=c(0, 1), ylim=c(0, 1), bty ="n",axes=F,
     frame.plot=F, xaxt='n', ann=FALSE, yaxt='n')

# Communities 2 & 3 closer to each other:
Community23 <- SyntheticData(SpeciesNum=40, CommunityNum=4, SpCo=c(10,10,10,10), 
                             Length = 500,
                             Parameters=list(a=c(60, 60, 60, 60), 
                                             b=c(0, 250, 500, 400), 
                                             c=c(0.012, 0.015, 0.012, 0.009)),
                            dev.c=.0024, dev.a = 20, dev.b = 30, 
                            pal=c("#008585","#B8CDAE","#C7522B", "#F9C29C"),
                            title = "G: Communities 2 & 3 share species")
## Analyses (second case):
Fuzzy23 <- EcotoneFinder(Community23[,2:ncol(Community23)], dist = Community23$Distance, 
                        method = c("cmeans"), groups = 3, m.exp = 2,
                        standardize = "hellinger")

## Networks:
NetworkEco(Fuzzy23, plot.type = "network", method = "cmeans", 
           dist.method = "inner_product", 
           plot = "community", dist = "raw", layout = "spring")
title(main  = "H: Raw distances", adj = 0, cex = .5)
NetworkEco(Fuzzy23, plot.type = "network", method = "cmeans", 
           dist.method = "inner_product", 
           plot = "community", dist = "relative", layout = "spring")
title(main  = "I: Relative distances", adj = 0, cex = .5)
NetworkEco(Fuzzy23, plot.type = "network", method = "cmeans", 
           dist.method = "inner_product", 
           plot = "community", dist = "count", threshold = 0.25, layout = "spring")
title(main  = "J: Number of shared species", adj = 0, cex = .5)

###### Now comparing species with each other:
plot(NULL, xlim=c(0, 1), ylim=c(0, 1), bty ="n",axes=F,
     frame.plot=F, xaxt='n', ann=FALSE, yaxt='n')
NetworkEco(Fuzzy23, plot.type = "network", method = "cmeans", 
           dist.method = "inner_product", 
           plot = "species", dist = "raw", layout = "spring",
           network.group = as.factor(rep(c("C1", "C2", "C3", "Shared C2/C3"), 
                                         each = 10)),
           color = c("#008585","#B8CDAE","#C7522B", "#F9C29C"))
title(main  = "K: Raw distances", adj = 0, cex = .5)
NetworkEco(Fuzzy23, plot.type = "network", method = "cmeans", 
           dist.method = "inner_product", 
           plot = "species", dist = "relative", layout = "spring",
           network.group = as.factor(rep(c("C1", "C2", "C3", "Shared C2/C3"), 
                                         each = 10)),
           color = c("#008585","#B8CDAE","#C7522B", "#F9C29C"))
title(main  = "L: Relative distances", adj = 0, cex = .5)
plot(NULL, xlim=c(0, 1), ylim=c(0, 1), bty ="n",axes=F,
     frame.plot=F, xaxt='n', ann=FALSE, yaxt='n')


## ----Fig22, warning=FALSE, message=FALSE, fig.show="hold", out.width='34%', fig.align="center", fig.cap="Heatmaps and corrplot visualisations. It can be seen on the hierarchical tree of the heatmaps that the external group changes (either 3 or 1), and that the number of shared species between communities is correctly represented on the corrplots."----
## First case:
NetworkEco(Fuzzy12, plot.type = "heatmap", method = "cmeans", 
           dist.method = "inner_product", 
           plot = "community", dist = "raw")
NetworkEco(Fuzzy12, plot.type = "corrplot", method = "cmeans", 
           dist.method = "inner_product", 
           plot = "community", dist = "count", threshold = 0.25, method.corr = "number", 
           is.corr = FALSE)

# Second case:
NetworkEco(Fuzzy23, plot.type = "heatmap", method = "cmeans", 
           dist.method = "inner_product", 
           plot = "community", dist = "raw")
NetworkEco(Fuzzy23, plot.type = "corrplot", method = "cmeans", 
           dist.method = "inner_product", 
           plot = "community", dist = "count", threshold = 0.25, method.corr = "number",
           is.corr = FALSE)


## ----Fig23, echo=FALSE, fig.align="center", fig.cap="Schematic ecotone, with the graphical representation of its Magnitude of depth influence (MEI), Depth of Edge Influence (DEI), and Amplitude of Edge Influence (AEI).", out.width = '70%'----
knitr::include_graphics("EdgeResponse.pdf")

## ----Fig24, warning=FALSE, message=FALSE, fig.show="hold", out.width='50%', fig.cap="Comparison of the cmeans fuzzy algorythm membership variations and their derivatives."----
# Slope calculation:
EcoSlope <- Slope(EcoFind, method = c("cmeans", "diversity"), window = 3, 
                  diversity = "richness")

# Fuzzy clusters and derivatives (ggplot grammar):
Plot <- ggEcotone(EcoFind, slope = EcoSlope, plot.data = FALSE,
                  method = c("cmeans", "cmeans_slope"),
                  facet = c("cmeans", "cmeans_slope"),
                  col = c("#D33F6A", "#E99A2C", "#E2E6BD"),
                  title = "fuzzy clusters and their derivatives",
                  xlab = "Gradient", ylab = "Membership grades") + 
  theme_bw() + 
  theme(plot.title = element_text(hjust = 0.5, face="bold"))
Plot

# Fuzzy clusters and derivatives (basic plot):
plotEcotone(data = EcoFind, slope = EcoSlope, plot.data = FALSE, 
            plot.method = c("cmeans", "cmeans_slope"), 
            col.method = c("#D33F6A", "#E99A2C", "#E2E6BD"), 
            col.slope = c("#008585","#B8CDAE","#C7522B"), 
            ylab = "Memberships & derivatives",
            magnification.slope = 100)

## ----Tab1, warning=FALSE, message=FALSE, results = "asis"---------------------
# Derivative values:
pander::pandoc.table(head(EcoSlope$cmeans_slope), keep.line.breaks = T, justify = "lccc",
                     style = 'rmarkdown', row.names = c(1:6),
                     caption = "Derivative values for the three clusters. 
                                Only the first few values are being presented")


## ---- warning=FALSE, message=FALSE, results = "markup"------------------------
## Ecotone parameters:
# AEImax and AEImin:
AEImin <- min(EcoSlope$cmeans_slope[,1]) # Cluster 1
AEImax <- max(EcoSlope$cmeans_slope[,2]) # Cluster 2
AEImin
AEImax

# MEI (the interval needs to be specified, to target the first ecotone, but can be broad):
MEI_1 <- max(EcoFind$cmeans$membership[0:250,1]) - min(EcoFind$cmeans$membership[0:250,2])
MEI_2 <- min(EcoFind$cmeans$membership[0:250,1]) - max(EcoFind$cmeans$membership[0:250,2])

# DEI:
# Visually: from 90 to 200.
# With second derivatives:
EcoSlopeSecond <- Slope(EcoSlope$cmeans_slope, 
                        method = c("custom"), window = 21)

# The ecotone would be between the minimum and maximum values:
DEI_start <- which(EcoSlopeSecond$Slope_1 == min(EcoSlopeSecond$Slope_1[70:250,1])) 
DEI_end <-which(EcoSlopeSecond$Slope_1 == max(EcoSlopeSecond$Slope_1[70:250,1])) 
DEI_start
DEI_end
# Length along the gradient:
DEI_1 <- DEI_end - DEI_start
DEI_1

# Or alternatively, at the cross-point between the derivatives of
# the two successive clusters (rounding may be necessary):
Interval <- as.numeric(which(round(EcoSlope$cmeans_slope[0:250,1], digits = 3) ==
                      round(EcoSlope$cmeans_slope[0:250,2], digits = 3)))
Interval


## ---- echo = FALSE, warning=FALSE, message=FALSE------------------------------
if (any(Interval) < 50) {
  show.text <- TRUE } else {
    show.text <- FALSE
  }

## ---- warning=FALSE, message=FALSE, results = "markup"------------------------
DEI_2 <- Interval[which(Interval > 120)[1]] - Interval[which(Interval > 50)[1]]
DEI_2

## ---- warning=FALSE, message=FALSE, results = "markup"------------------------
# If calculated from the second derivatives:
AEI <- mean(c(MEI_1, MEI_2))/DEI_1
AEI

# If calculated from the first derivatives:
AEI <- mean(c(MEI_1, MEI_2))/DEI_2
AEI

# If estimated visually:
AEI <- mean(c(MEI_1, MEI_2))/(200 - 90)
AEI
  

## ----Fig25, warning=FALSE, message=FALSE, fig.show="hold", fig.align="center", out.width='50%', fig.cap="Artificail communities, with some variation in the species response around the ecotone. A 'third' community has been created to introduce some ecotonal species, in the sense that their abundance maxima are centred on the ecotone."----

# Two communities with a reasonable amount of variability in species responses:
Community3 <- SyntheticData(SpeciesNum = 30, CommunityNum = 3, SpCo = c(13,4,13), 
                            Length = 500, Parameters = list(a = c(60,30,60), 
                                                            b = c(0,250,500), 
                                                            c = c(0.009,0.015,0.009)), 
                            dev.c = .005, 
                            dev.a = c(50,20,50), dev.b = 60, 
                            pal = c("#008585", "green", "#C7522B"))

# And corresponding analyses:
Fuzzy2 <- EcotoneFinder(Community3[,2:ncol(Community3)], dist = Community3$Distance, 
                        method = c("cmeans"), groups = 2, m.exp = 2,
                        standardize = "hellinger")


## ----Fig26, warning=FALSE, message=FALSE, fig.show="hold", out.width='45%', fig.cap="Example of two species respose type, one (on the left) crossing the community-wide demarcation of the ecotone, thus termed 'crossing' response, and another (on the right) falling short from it, thus termed 'negative' response."----
### Fuzzy clusters and individual species:
# Base plot:
Plot <- ggEcotone(Fuzzy2, plot.data = FALSE,
                  method = c("cmeans"),
                  col = c("#D33F6A", "#E2E6BD"),
                  title = "fuzzy clusters",
                  xlab = "Gradient", ylab = "Membership grades") + 
  theme_bw() + 
  theme(plot.title = element_text(hjust = 0.5, face="bold"))

## Selecting interesting cases:
FirstCom <- Community3[,1:13]
# trespassing the ecotone:
Crossings <- which(apply(FirstCom[250:500,-1], MARGIN = 2, sum) > 50)
# Stoping short:
Negatives <- which(apply(FirstCom[250:500,-1], MARGIN = 2, sum) < 10)

# Adding species (dividing by their maximum abundances, 
# to match the [0,1] range of the fuzzy clusters:
Plot1 <- Plot +
  geom_line(aes(x = Community3$Distance, 
            y = Community3[,names(Crossings[1])]/max(Community3[,names(Crossings[1])])), 
            col = "blue")
Plot1

Plot2 <- Plot +
  geom_line(aes(x = Community3$Distance, 
            y = Community3[,names(Negatives[1])]/max(Community3[,names(Negatives[1])])), 
            col = "darkgreen")
Plot2


## ----Fig27, warning=FALSE, message=FALSE, fig.show="hold", out.width='49%', fig.cap="Community cluster shapes depending on the number of clusters. If a third cluster is drawn, it captures the particular ecotonal community structure, which is mostly driven by variations in individual species abundances along the gradient, but also by the potential presence of ecotonal species."----
## Forcing a third 'ecotonal' community:
Fuzzy3 <- EcotoneFinder(Community3[,2:ncol(Community3)], dist = Community3$Distance, 
                        method = c("cmeans"), groups = 3, m.exp = 2,
                        standardize = "hellinger")

## Comparing clusters:
PlotF2 <- ggEcotone(Fuzzy2, plot.data = FALSE,
                  method = c("cmeans"),
                  col = c("#D33F6A", "#E2E6BD"),
                  title = "2 fuzzy clusters",
                  xlab = "Gradient", ylab = "Membership grades") + 
  theme_bw() + 
  theme(plot.title = element_text(hjust = 0.5, face="bold"))

PlotF3 <- ggEcotone(Fuzzy3, plot.data = FALSE,
                  method = c("cmeans"),
                  col = c("#D33F6A", "green", "#E2E6BD"),
                  title = "3 fuzzy clusters",
                  xlab = "Gradient", ylab = "Membership grades") + 
  theme_bw() + 
  theme(plot.title = element_text(hjust = 0.5, face="bold"))

PlotF2
PlotF3

## Corresponding centroids:
CentroidsF2 <- ExtractCentroid(Fuzzy2, method = "cmeans", normalized = "cluster", 
                             plot = FALSE, cex.x = 9, col=c("#A1A6C8", "#CA9CA4"))
CentroidsF2$GGplot +
  theme(legend.position = "none")

CentroidsF3 <- ExtractCentroid(Fuzzy3, method = "cmeans", normalized = "cluster", 
                             plot = FALSE, cex.x = 9, 
                             col=c("#A1A6C8", "green", "#CA9CA4"))
CentroidsF3$GGplot +
  theme(legend.position = "none")


## ---- echo = FALSE, warning=FALSE, message=FALSE------------------------------

index <- NULL
for (i in 1:length(levels(CentroidsF3$centroids$Species))) {
  max <- max(
    CentroidsF3$centroids[CentroidsF3$centroids$Species == levels(CentroidsF3$centroids$Species)[i],]$Contribution)
  index[i] <- rownames(CentroidsF3$centroids[CentroidsF3$centroids$Contribution == max,])
}

if (length(which(CentroidsF3$centroids[index,]$Cluster == 2)) > 4) {
  show.text <- TRUE } else {
    show.text <- FALSE
  }


## ----Fig28, warning=FALSE, message=FALSE, fig.show="hold", out.width='33%', fig.cap="Time series with displacement: part of the first community (left) advances toward the right-end of the gradient by 35 gradient units per series, as if reacting to a moving environmental variable or gradient. The last community also withdraw further to the right, but more slowly (10 gradient units per series)."----
## Displacement matrix:
disp <- matrix(data=c(0,0,0,
                      0,35,-0.0007,
                      0,10,0), nrow = 3, ncol = 3)

### Series:
Series <- SyntheticDataSeries(CommunityPool = 60, CommunityNum = 3, Length = 500,
                              SeriesNum = 6, replacement = FALSE, SpCo = c(15,15,30),
                              Parameters = list(a = c(60,60,60),
                                                b = c(-50,-50,400),
                                                c = c(0.01, 0.01, 0.01)),
                              dev.a=c(30,50,30), 
                              dev.b=c(40,10,30),
                              dev.c=c(0,.0001,0),
                              displacement = disp,
                              pal = c(rep("#008585",15), rep("#E6C186",15),
                                      rep("#C7522B",30)))
 

## ----Fig29, warning=FALSE, message=FALSE, fig.show="hold", out.width='33%', fig.cap="Evolution of the fuzzy clusters and of the first axis of the DCA along the gradient for each sampling event in the artificial series."----
## All analyses (considering 3 groups):
EcoSeries <- EcotoneFinderSeries(data = Series,
                                 dist = "Distance", 
                                 method = c("cmeans", "dca", "diversity"),
                                 diversity = c("richness", "expShannon"),
                                 series = "Time", groups = 3,
                                 standardize = "hellinger", na.rm = TRUE)

## Plotting only requires a loop:
Plot <- list()
for (i in names(EcoSeries)) {
  Plot[[i]] <- ggEcotone(EcoSeries[[i]], plot.data = FALSE,
                         method = c("cmeans", "dca"),
                         col = c("#D33F6A", "#E99A2C", "#E2E6BD"),
                         facet = c("cmeans", "dca"),
                         title = paste(i), xlab = "Gradient", 
                         ylab = "Membership grades and first DCA axis") + 
  theme_bw() + 
  theme(plot.title = element_text(hjust = 0.5, face="bold"))
}

Plot[[1]]
Plot[[2]]
Plot[[3]]
Plot[[4]]
Plot[[5]]
Plot[[6]]

## ----Fig30, warning=FALSE, message=FALSE, fig.show="hold", out.width='33%', fig.cap="Evolution of the species richness and the exponential of the Shannon entropy along the gradient for each of hte sampling event of the series. The generated species distribution data and the evolution of the fuzzy clusters are given again, for comparison purposes. This example easily illustrates how diversity patterns and statistical community structures can be disjoinct, even with simple ecological data."----
## Ploting only requires a loop:
# colour gradient:
Colours <- c("grey60", "cadetblue", "gold")
Plot <- list()
for (i in names(EcoSeries)) {
  Plot[[i]] <- ggEcotone(EcoSeries[[i]], plot.data = TRUE,
                         method = c("cmeans", "diversity"),
                         col = Colours,
                         facet = c("data", "cmeans", "diversity"),
                         title = paste(i), xlab = "Gradient", 
                         ylab = "Species richness and shannon entropy (exp.)") + 
  theme_bw() + 
  theme(plot.title = element_text(hjust = 0.5, face="bold"))
}

Plot[[1]]
Plot[[2]]
Plot[[3]]
Plot[[4]]
Plot[[5]]
Plot[[6]]

## ----Fig31, warning=FALSE, message=FALSE, fig.show="hold", out.width='45%', fig.cap="Networks of associations between main community types (based on fuzzy cluster centroid compositions). The centroid species scores are unmodified (raw) and the topology of the network -- the relative position of the nodes and length of the edges -- relies on the inner product similarity measure. The colouring of the nodes either follows (A) the positions of the communities along the gradient or (B) the sampling event, here chosen to be 'Times'"----
NetworkSeries <- NetworkEcoSeries(EcoSeries,
                                  method = "cmeans", plot.type = "network",
                                  plot = "community", dist = "raw",
                                  network.group = "cluster",
                                  dist.method = "inner_product",
                                  no.plot = FALSE, layout = "spring",
                                  shape = "ellipse",
                                  palette = "colorblind")
title(main = "A: By common species counts \n coloured by clusters", 
      adj = .9, cex.main = .7, outer = FALSE)

NetworkSeries <- NetworkEcoSeries(EcoSeries, 
                                  method = "cmeans", plot.type = "network",
                                  plot = "community", dist = "raw",
                                  network.group = "site",
                                  dist.method = "inner_product",
                                  no.plot = FALSE, layout = "spring",
                                  shape = "ellipse",
                                  palette = "colorblind")
title(main = "B: By common species counts \n coloured by sampling events", 
      adj = .9, cex.main = .7, outer = FALSE)


## ----Fig32, warning=FALSE, message=FALSE, fig.show="hold", out.width='45%', fig.cap="Networks of associations between main community types (based on fuzzy cluster centroid compositions). The centroid species scores are unmodified (raw) and the topology of the network -- the relative position of the nodes and length of the edges -- either relies on (A) the inner product similarity measure or (B) the jaccard dissimilarity measure. Similarity calculations are more adapted to network of this kind, as they put similar nodes closer to one another."----
NetworkSeries <- NetworkEcoSeries(EcoSeries,
                                  method = "cmeans", plot.type = "network",
                                  plot = "community", dist = "raw",
                                  network.group = "cluster",
                                  dist.method = "intersection",
                                  no.plot = FALSE, layout = "spring",
                                  shape = "ellipse",
                                  palette = "colorblind")
title(main = "A: By common species counts \n coloured by clusters", 
      adj = .9, cex.main = .7, outer = FALSE)

NetworkSeries <- NetworkEcoSeries(EcoSeries, 
                                  method = "cmeans", plot.type = "network",
                                  plot = "community", dist = "raw",
                                  network.group = "cluster",
                                  dist.method = "jaccard",
                                  no.plot = FALSE, layout = "spring",
                                  shape = "ellipse",
                                  palette = "colorblind")
title(main = "B: By common species counts \n coloured by sampling events", 
      adj = .9, cex.main = .7, outer = FALSE)


## ----Fig33, warning=FALSE, message=FALSE, fig.show="hold", out.width='45%', fig.cap="Networks of associations between main community types (based on fuzzy cluster centroid compositions). The centroid species scores are either (A) unmodified ('raw') or (B) standardized (divided by margin total). The corresponding network topology are mostly equivalent, but stadardized centroid values weaken the links between the intermediate clusters in the series (in blue), as their compositions are less stable over the artificial data series -- a difference overlooked by raw cluster centroid inputs."----
NetworkSeries <- NetworkEcoSeries(EcoSeries,
                                  method = "cmeans", plot.type = "network",
                                  plot = "community", dist = "raw",
                                  network.group = "cluster",
                                  dist.method = "inner_product",
                                  no.plot = FALSE, layout = "spring",
                                  shape = "ellipse",
                                  palette = "colorblind")
title(main = "A: By common species counts \n coloured by clusters", 
      adj = .9, cex.main = .7, outer = FALSE)

NetworkSeries <- NetworkEcoSeries(EcoSeries, 
                                  method = "cmeans", plot.type = "network",
                                  plot = "community", dist = "relative",
                                  network.group = "cluster",
                                  dist.method = "inner_product",
                                  no.plot = FALSE, layout = "spring",
                                  shape = "ellipse",
                                  palette = "colorblind")
title(main = "B: By common species counts \n coloured by sampling events", 
      adj = .9, cex.main = .7, outer = FALSE)


## ----Fig34, warning=FALSE, message=FALSE, fig.show="hold", out.width='45%', fig.cap="Networks of associations between species in the artificial data series (based on fuzzy cluster centroid compositions). The centroid species scores are either (A) unmodified ('raw') or (B) standardized (divided by margin total). With such simple data structure, Tthe main community types may be identified back due to the pooling of groups of species together."----
NetworkSeries <- NetworkEcoSeries(EcoSeries, threshold = .5,
                                  method = "cmeans", plot.type = "network",
                                  plot = "species", dist = "raw",
                                  network.group = NULL,
                                  dist.method = "inner_product",
                                  no.plot = FALSE, layout = "spring",
                                  shape = "ellipse",
                                  color = c(rep("#008585",15), rep("#E6C186",15),
                                      rep("#C7522B",30)))
title(main = "A: By common species counts \n coloured according to 
      the artificial data structure", 
      adj = .9, cex.main = .7, outer = FALSE)

NetworkSeries <- NetworkEcoSeries(EcoSeries, threshold = .5,
                                  method = "cmeans", plot.type = "network",
                                  plot = "species", dist = "relative",
                                  network.group = NULL,
                                  dist.method = "inner_product",
                                  no.plot = FALSE, layout = "spring",
                                  shape = "ellipse",
                                  color = c(rep("#008585",15), rep("#E6C186",15),
                                      rep("#C7522B",30)))
title(main = "A: By common species counts \n coloured according to 
      the artificial data structure", 
      adj = .9, cex.main = .7, outer = FALSE)


## ----Fig35, warning=FALSE, message=FALSE, fig.show="hold", out.width='45%', fig.cap="Networks of associations between species in the artificial data series (based on fuzzy cluster centroid compositions). The centroid species scores are either (A) unmodified ('raw') or (B) standardized (divided by margin total). With such simple data structure, Tthe main community types may be identified back due to the pooling of groups of species together."----
# Using a previous community network (not plotting it this time):
NetworkSeries <- NetworkEcoSeries(EcoSeries,
                                  method = "cmeans", plot.type = "network",
                                  plot = "community", dist = "relative",
                                  network.group = "cluster",
                                  dist.method = "inner_product",
                                  no.plot = TRUE, layout = "spring",
                                  shape = "ellipse",
                                  palette = "colorblind")

# Making use of the previous network:
CommunityID <- NetworkCommunity(NetworkSeries, run = 10)

NetworkSeriesSpin <- NetworkEcoSeries(EcoSeries, 
                          method = "cmeans", plot.type = "network",
                          plot = "community", dist = "relative",
                          network.group = as.factor(CommunityID$Memberships$RoundedMean),
                          dist.method = "inner_product",
                          no.plot = FALSE, layout = "spring",
                          shape = "ellipse")
title(main = "A: By common species counts \n coloured according to 
      \n spinglass algoritm outputs (rounded)",
      adj = .9, cex.main = .7, outer = FALSE)

NetworkSeriesSpin <- NetworkEcoSeries(EcoSeries, threshold = .5,
                          method = "cmeans", plot.type = "network",
                          plot = "community", dist = "relative",
                          network.group = as.factor(CommunityID$Memberships$Mean),
                          dist.method = "inner_product",
                          no.plot = FALSE, layout = "spring",
                          shape = "ellipse")
title(main = "A: By common species counts \n coloured according to 
      \n spinglass algorithm outputs (not rounded)",
      adj = .9, cex.main = .7, outer = FALSE)


