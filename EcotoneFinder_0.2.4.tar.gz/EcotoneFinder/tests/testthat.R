library(testthat)
library(EcotoneFinder)

test_check("EcotoneFinder")
